#include <stdio.h>

void main()
{
	printf("Our IDs are: 315337238_205577018\n");
}